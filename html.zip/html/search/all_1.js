var searchData=
[
  ['kommentarklasse',['KommentarKlasse',['../class_class_demo_kommentarer_lib_1_1math_1_1_kommentar_klasse.html',1,'ClassDemoKommentarerLib::math']]],
  ['kommentarworker',['KommentarWorker',['../class_class_demo_kommentarer_1_1_kommentar_worker.html',1,'ClassDemoKommentarer']]]
];
